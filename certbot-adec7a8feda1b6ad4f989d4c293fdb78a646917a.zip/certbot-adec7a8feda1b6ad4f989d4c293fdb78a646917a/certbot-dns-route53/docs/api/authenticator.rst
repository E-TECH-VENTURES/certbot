:mod:`certbot_dns_route53.authenticator`
----------------------------------------

.. automodule:: certbot_dns_route53.authenticator
   :members:
