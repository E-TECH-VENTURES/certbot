"""Internal implementation of `~certbot_dns_gehirn.dns_gehirn` plugin."""
