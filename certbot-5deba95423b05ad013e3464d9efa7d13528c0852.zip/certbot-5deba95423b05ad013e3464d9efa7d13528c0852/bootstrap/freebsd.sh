#!/bin/sh -xe

pkg install -Ay \
  git \
  python \
  py27-virtualenv \
  augeas \
  libffi \
