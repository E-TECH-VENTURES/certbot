Nginx plugin for Let's Encrypt client
